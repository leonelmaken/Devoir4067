public class BlueColor implements Color{

    @Override
    public void fillColor() {
        System.out.println("blue color");
    }
    
}
