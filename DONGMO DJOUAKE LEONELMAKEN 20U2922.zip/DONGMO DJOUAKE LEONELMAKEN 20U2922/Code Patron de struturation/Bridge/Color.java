public interface Color {

    public void fillColor();
}