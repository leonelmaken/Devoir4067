public interface Fenetre {
    void afficher();
}
