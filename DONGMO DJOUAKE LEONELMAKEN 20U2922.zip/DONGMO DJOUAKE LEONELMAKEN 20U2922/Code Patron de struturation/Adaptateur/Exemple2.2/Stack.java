public interface Stack {
    void push(int data);
    int pop();
    int top();
}
