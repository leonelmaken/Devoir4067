package Exemple3;

public interface Carre {
    float perimetre();
    float aire();
}
