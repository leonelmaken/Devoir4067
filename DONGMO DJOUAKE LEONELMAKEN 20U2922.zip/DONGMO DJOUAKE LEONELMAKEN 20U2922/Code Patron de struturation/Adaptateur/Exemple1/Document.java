public interface Document {
    int setContenu();
    int dessine();
    int imprime();
}
