package Exemple2;

interface Stack {
    void push(Object o);
    Object pop();
    Object top();
}
