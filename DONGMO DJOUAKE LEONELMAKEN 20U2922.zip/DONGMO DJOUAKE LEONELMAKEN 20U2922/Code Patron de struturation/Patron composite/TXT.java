public class TXT extends Fichier {
    public TXT(String nom) {
        super(nom, "txt");
    }
}
