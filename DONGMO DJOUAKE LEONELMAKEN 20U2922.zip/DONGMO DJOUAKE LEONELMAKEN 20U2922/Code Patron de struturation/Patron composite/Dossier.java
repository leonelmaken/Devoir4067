public class Dossier extends Repertoire {
    public Dossier(String nom) {
        super(nom, "dossier");
    }
}
