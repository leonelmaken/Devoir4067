public class PDF extends Fichier {
    public PDF(String nom) {
        super(nom, "pdf");
    }
}
