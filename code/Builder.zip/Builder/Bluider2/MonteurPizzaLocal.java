class MonteurPizzaLocal extends MonteurPizza {
public void monterPate()
{ pizza.setPate("tendue");
   pizza.setNom("Local"); }
public void monterSauce()
{ pizza.setSauce("Jaune"); }
public void monterGarniture() {
pizza.setGarniture("Poulet+Tomate"); }
}