class MonteurPizzaPiquante extends MonteurPizza {
public void monterPate()
{ pizza.setPate("feuilletée");  pizza.setNom("Piquante");}
public void monterSauce()
{ pizza.setSauce("piquante"); }
public void monterGarniture() { pizza.setGarniture("pepperoni+salami");
}
}