class MonteurPizzaReine extends MonteurPizza {
public void monterPate()
{ pizza.setPate("croisée");
   pizza.setNom("Reine"); }
public void monterSauce()
{ pizza.setSauce("douce"); }
public void monterGarniture() {
pizza.setGarniture("jambon+champignon"); }
}